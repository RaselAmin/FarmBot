package com.nasaappschallenge.farmbot;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.StringTokenizer;
import java.util.UUID;

public class MainActivity extends Activity implements CompoundButton.OnCheckedChangeListener {

    private Switch switchFertilization=null, switchIrrigation=null, switchPestControl=null, switchSeedSpread=null;
    private Boolean statusUpdated = false;

    private TextView txtArduino, txtString, txtStringLength, sensorMoistureTV, sensorTemperatureTV, sensorHumidityTV, sensorPhTV, sensorMethaneTV, sensorCoTV;

    Handler bluetoothIn;

    final int handlerState = 0;        				 //used to identify handler message
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private StringBuilder recDataString = new StringBuilder();

    private ConnectedThread mConnectedThread;

    // SPP UUID service - this should work for most devices
    private static final UUID BTMODULEUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // String for MAC address
    private static String address;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchFertilization = (Switch) findViewById(R.id.switchFertilization);
        switchIrrigation = (Switch) findViewById(R.id.switchIrrigation);
        switchPestControl = (Switch) findViewById(R.id.switchPestControl);
        switchSeedSpread = (Switch) findViewById(R.id.switchSeedSpread);

        switchFertilization.setOnCheckedChangeListener(this);
        switchIrrigation.setOnCheckedChangeListener(this);
        switchPestControl.setOnCheckedChangeListener(this);
        switchSeedSpread.setOnCheckedChangeListener(this);


        txtString = (TextView) findViewById(R.id.txtString);
        txtStringLength = (TextView) findViewById(R.id.testView1);

        sensorMoistureTV = (TextView) findViewById(R.id.sensorMoistureTV);
        sensorTemperatureTV = (TextView) findViewById(R.id.sensorTemperatureTV);
        sensorHumidityTV = (TextView) findViewById(R.id.sensorHumidityTV);
        sensorPhTV = (TextView) findViewById(R.id.sensorPhTV);
        sensorMethaneTV = (TextView) findViewById(R.id.sensorMethaneTV);
        sensorCoTV = (TextView) findViewById(R.id.sensorCoTV);

        Toast.makeText(getApplicationContext(), "MAIN", Toast.LENGTH_SHORT).show();

        bluetoothIn = new Handler() {
            public void handleMessage(android.os.Message msg) {
                if (msg.what == handlerState) {										//if message is what we want
                    String readMessage = (String) msg.obj;                                                                // msg.arg1 = bytes from connect thread
                    recDataString.append(readMessage);      								//keep appending to string until ~
                    int endOfLineIndex = recDataString.indexOf("~");                    // determine the end-of-line
                    if (endOfLineIndex > 0) {                                           // make sure there data before ~
                        String dataInPrint = recDataString.substring(0, endOfLineIndex);    // extract string
                        txtString.setText("Data Received = " + dataInPrint);
                        int dataLength = dataInPrint.length();							//get length of data received
                        txtStringLength.setText("String Length = " + String.valueOf(dataLength));

                        if (recDataString.charAt(0) == '#')	{							//if it starts with # we know it is what we are looking for
                            StringTokenizer tokens = new StringTokenizer(dataInPrint.substring(1,dataInPrint.length()), "+");

                            String m1 = tokens.nextToken();
                            String m2 = tokens.nextToken();
                            String m3 = tokens.nextToken();
                            String m4 = tokens.nextToken();

                            String moisture = tokens.nextToken();
                            String temperature = tokens.nextToken();
                            String humidity = tokens.nextToken();
                            String ph = tokens.nextToken();
                            String methane = tokens.nextToken();
                            String co = tokens.nextToken();

                            //update the textviews with sensor values
                            sensorMoistureTV.setText(moisture + "");
                            sensorTemperatureTV.setText(String.format("%.2f",Float.valueOf(temperature) / 12) + "°");
                            sensorHumidityTV.setText(humidity + "");
                            sensorPhTV.setText(ph + "");
                            sensorMethaneTV.setText(methane + "");
                            sensorCoTV.setText(co + "");



                            if(!statusUpdated) {
                                switchFertilization.setChecked(m1.equals("1")); // T || F;
                                switchIrrigation.setChecked(m2.equals("1")); // T || F;
                                switchPestControl.setChecked(m3.equals("1")); // T || F;
                                switchSeedSpread.setChecked(m4.equals("1")); // T || F;

                                statusUpdated = true;
                            }
                        }
                        recDataString.delete(0, recDataString.length()); 					//clear all string data
                        // strIncom =" ";
                        dataInPrint = " ";
                    }
                }
            }
        };

        btAdapter = BluetoothAdapter.getDefaultAdapter();       // get Bluetooth adapter
        checkBTState();
    }

    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        return  device.createRfcommSocketToServiceRecord(BTMODULEUUID);
        //creates secure outgoing connecetion with BT device using UUID
    }

    @Override
    public void onResume() {
        super.onResume();

        statusUpdated = false; //Re-Check machine statuses;

        //Get MAC address from DeviceListActivity via intent
        Intent intent = getIntent();

        //Get the MAC address from the DeviceListActivty via EXTRA
        address = intent.getStringExtra(DeviceListActivity.EXTRA_DEVICE_ADDRESS);

        //create device and set the MAC address
        BluetoothDevice device = btAdapter.getRemoteDevice(address);

        try {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e) {
            Toast.makeText(getBaseContext(), "Socket creation failed", Toast.LENGTH_LONG).show();
        }

        // Establish the Bluetooth socket connection.
        try {
            btSocket.connect();
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2){
                //insert code to deal with this
            }
        }
        mConnectedThread = new ConnectedThread(btSocket);
        mConnectedThread.start();

        //I send a character when resuming.beginning transmission to check device is connected
        //If it is not an exception will be thrown in the write method and finish() will be called
        mConnectedThread.write("x");
    }

    @Override
    public void onPause(){
        super.onPause();
        try {
            //Don't leave Bluetooth sockets open when leaving activity
            btSocket.close();
        } catch (IOException e2) {
            //insert code to deal with this
        }
    }

    //Checks that the Android device Bluetooth is available and prompts to be turned on if off
    private void checkBTState() {

        if(btAdapter==null) {
            Toast.makeText(getBaseContext(), "Device does not support bluetooth", Toast.LENGTH_LONG).show();
        } else {
            if (btAdapter.isEnabled()) {
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(statusUpdated){
            switch (buttonView.getId()){
                case R.id.switchFertilization:
                    if (isChecked) {
                        mConnectedThread.write("1");    // Send "1" via Bluetooth
                        Toast.makeText(this, "Fertilization Machine is ON", Toast.LENGTH_SHORT).show();
                    } else {
                        mConnectedThread.write("0");    // Send "0" via Bluetooth
                        Toast.makeText(this, "Fertilization Machine is OFF", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.switchIrrigation:
                    if (isChecked) {
                        //statusLED = true;
                        mConnectedThread.write("3");
                        Toast.makeText(this, "Irrigation Machine is ON", Toast.LENGTH_SHORT).show();
                    } else {
                        //statusLED = false;
                        mConnectedThread.write("2");
                        Toast.makeText(this, "Irrigation Machine is OFF", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.switchPestControl:
                    if (isChecked) {
                        mConnectedThread.write("5");
                        Toast.makeText(this, "Pest Control Machine is ON", Toast.LENGTH_SHORT).show();
                    } else {
                        mConnectedThread.write("4");
                        Toast.makeText(this, "Pest Control Machine is OFF", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.switchSeedSpread:
                    if (isChecked) {
                        mConnectedThread.write("7");
                        Toast.makeText(this, "Seed Spread Machine is ON", Toast.LENGTH_SHORT).show();
                    } else {
                        mConnectedThread.write("6");
                        Toast.makeText(this, "Seed Spread Machine is OFF", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    }

    //create new class for connect thread
    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        //creation of the connect thread
        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                //Create I/O streams for connection
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[256];
            int bytes;

            // Keep looping to listen for received messages
            while (true) {
                try {
                    bytes = mmInStream.read(buffer);        	//read bytes from input buffer
                    String readMessage = new String(buffer, 0, bytes);
                    // Send the obtained bytes to the UI Activity via handler
                    bluetoothIn.obtainMessage(handlerState, bytes, -1, readMessage).sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }
        }
        //write method
        public void write(String input) {
            byte[] msgBuffer = input.getBytes();           //converts entered String into bytes
            try {
                mmOutStream.write(msgBuffer);                //write bytes over BT connection via outstream
            } catch (IOException e) {
                //if you cannot write, close the application
                Toast.makeText(getBaseContext(), "Connection Failure", Toast.LENGTH_LONG).show();
                finish();

            }
        }
    }
}

